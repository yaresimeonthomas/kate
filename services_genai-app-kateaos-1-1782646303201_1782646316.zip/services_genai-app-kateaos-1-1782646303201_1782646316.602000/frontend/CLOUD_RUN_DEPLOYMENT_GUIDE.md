# How to Deploy Kate AOS to Google Cloud Run

You mentioned you want to deploy this to **Google Cloud Run**. This is an excellent choice! Cloud Run is incredibly scalable, handles custom domains easily, and allows you to securely inject your API keys as environment variables without needing a `.env` file.

Because Cloud Run is designed to run *containers* (Docker), we need to package this React app into a Docker container that serves the static files.

Here is the exact, step-by-step process to get this live on Cloud Run today:

## Step 1: Prepare your local environment
1. Download and install [Node.js](https://nodejs.org/) on your computer.
2. Download and install [Docker Desktop](https://www.docker.com/products/docker-desktop/).
3. Download and install the [Google Cloud CLI](https://cloud.google.com/sdk/docs/install).

## Step 2: Create the Project Files
Open your computer's Terminal or Command Prompt and run these commands:
```bash
npm create vite@latest kate-aos -- --template react-ts
cd kate-aos
npm install firebase @google/genai lucide-react express
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

Replace the contents of the generated `src` folder with all the `.tsx` and `.ts` files from this project.

Update your `tailwind.config.js`:
```javascript
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

## Step 3: Create the Server and Docker Files
Because Cloud Run needs a web server to serve your files, we will create a tiny Express server.

Create a file named `server.js` in the root of your project:
```javascript
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 8080;

// Serve static files from the dist directory
app.use(express.static(path.join(__dirname, 'dist')));

// Send all other requests to index.html (for React Router)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
```

Create a file named `Dockerfile` in the root of your project:
```dockerfile
# Build stage
FROM node:20-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

# Production stage
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY --from=build /app/dist ./dist
COPY server.js ./
EXPOSE 8080
CMD ["node", "server.js"]
```

Create a file named `.dockerignore` in the root of your project:
```
node_modules
dist
.git
.env
```

## Step 4: Build and Deploy to Cloud Run
1. Authenticate with Google Cloud:
   ```bash
   gcloud auth login
   gcloud config set project kate-aos-pwa
   ```

2. Build and submit your container to Google Cloud Build:
   ```bash
   gcloud builds submit --tag gcr.io/kate-aos-pwa/kate-aos-app
   ```

3. Deploy the container to Cloud Run:
   ```bash
   gcloud run deploy kate-aos-app \
     --image gcr.io/kate-aos-pwa/kate-aos-app \
     --platform managed \
     --region us-central1 \
     --allow-unauthenticated \
     --set-env-vars="API_KEY=your-google-cloud-api-key,ZERNIO_API_KEY=sk_your_zernio_key,ZERNIO_ACCOUNT_ID=acc_your_zernio_account"
   ```
   *(Make sure to replace the placeholder API keys in the command above with your actual keys!)*

## Step 5: Confirm the Live URL
When the deployment finishes, the terminal will print out your **Service URL** (it will look something like `https://kate-aos-app-abcdefg-uc.a.run.app`). 

Click that link, and your app is live! 

To connect your custom domain, go to the **Cloud Run** page in the Google Cloud Console, click **Manage Custom Domains**, and follow the instructions to add the DNS records to your domain registrar.
